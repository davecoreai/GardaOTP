import { json, method } from '../lib/server.js';
export default function handler(req, res) {
  if (!method(req, res, ['GET'])) return;
  json(res, 200, {
    supabaseUrl: process.env.SUPABASE_URL || '',
    supabaseAnonKey: process.env.SUPABASE_ANON_KEY || ''
  });
}
